# MongoDB Data Modeling Demo

A simple Node.js/Express application demonstrating MongoDB data modeling with Mongoose, including user and task management with referenced relationships.

## Features

- User model with name, email, and timestamp
- Task model with title, description, completion status, and user reference
- CRUD operations for both users and tasks
- Population of referenced user data in tasks
- RESTful API endpoints

## Project Structure

```
data-modeling-demo/
├── config/
│   └── database.js       # MongoDB connection configuration
├── models/
│   ├── User.js          # User schema definition
│   └── Task.js          # Task schema with user reference
├── routes/
│   └── index.js         # API routes for CRUD operations
├── .env                 # Environment variables
├── server.js            # Main application entry point
├── package.json         # Project dependencies
└── README.md            # This file
```

## Installation

1. Install dependencies:
```bash
npm install
```

2. Configure MongoDB connection in `.env`:
```
MONGODB_URI=mongodb://localhost:27017/data-modeling-demo
PORT=3000
```

## Running the Application

Start the server:
```bash
npm start
```

The server will run on `http://localhost:3000`

## API Endpoints

### User Endpoints

- `POST /api/users` - Create a new user
  - Body: `{ "name": "John Doe", "email": "john@example.com" }`

- `GET /api/users` - Get all users

- `GET /api/users/:id` - Get a specific user by ID

### Task Endpoints

- `POST /api/tasks` - Create a new task
  - Body: `{ "title": "Task title", "description": "Task description", "userId": "user_id" }`

- `GET /api/tasks` - Get all tasks with populated user data

- `GET /api/tasks/:id` - Get a specific task with populated user data

- `GET /api/users/:userId/tasks` - Get all tasks for a specific user

- `PUT /api/tasks/:id` - Update a task
  - Body: `{ "title": "Updated title", "description": "Updated description", "completed": true }`

- `DELETE /api/tasks/:id` - Delete a task

## Testing with Postman or Thunder Client

1. Create a user:
   - Method: POST
   - URL: `http://localhost:3000/api/users`
   - Body: `{"name": "John Doe", "email": "john@example.com"}`

2. Create a task (use the user ID from step 1):
   - Method: POST
   - URL: `http://localhost:3000/api/tasks`
   - Body: `{"title": "Complete project", "description": "Finish the MongoDB demo", "userId": "<user_id_from_step_1>"}`

3. Get all tasks with populated user data:
   - Method: GET
   - URL: `http://localhost:3000/api/tasks`

4. Get tasks for a specific user:
   - Method: GET
   - URL: `http://localhost:3000/api/users/<user_id>/tasks`

## Data Models

### User Schema
```javascript
{
  name: String (required),
  email: String (required, unique),
  createdAt: Date (default: current date)
}
```

### Task Schema
```javascript
{
  title: String (required),
  description: String,
  completed: Boolean (default: false),
  userId: ObjectId (ref: 'User', required),
  createdAt: Date (default: current date)
}
```

## Technologies Used

- Node.js
- Express.js
- Mongoose
- MongoDB
- dotenv
